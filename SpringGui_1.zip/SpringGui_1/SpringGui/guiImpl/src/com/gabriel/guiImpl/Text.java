package com.gabriel.guiImpl;

import com.gabriel.guiFx.BaseShape;

public class Text extends BaseShape {
    private String text;

    public Text(String text) {
        super();
        this.text = text;
    }

    public String getText() {
        return text;
    }

}