package com.gabriel.guiFx;

public class BaseShape implements Shape{
	Location location;
	
	@Override
	public Location getLocation() {
		return location;
	}

	@Override
	public void setLocation(Location location) {
		this.location=location;
		
	}

}
