package com.gabriel.guiRenderer;

import java.awt.Graphics;

import com.gabriel.guiFx.Renderer;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Circle;

public class CircleRenderer implements Renderer {

	@Override
	public void draw(Object object, Shape shape) {
		Graphics g = (Graphics) object; 
		Circle circle= (Circle) shape; 
		g.drawOval(circle.getLocation().getX(), circle.getLocation().getY(), circle.width(), circle.height());
	}
}
