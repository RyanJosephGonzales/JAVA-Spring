package com.gabriel.guiMover;



import com.gabriel.guiFx.Mover;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Circle;
import com.gabriel.guiImpl.Rectangle;
import com.gabriel.guiImpl.Submarine;

public class SubmarineMover implements Mover {

	@Override
	public void move(Shape shape, int dx, int dy, int dz) {
		Submarine submarine = (Submarine) shape;
		Circle body = submarine.body();
		CircleMover circleMover=new CircleMover();
		circleMover.move(body, dx, dy, dz);
		
		Circle front = submarine.front();
		circleMover.move(front, dx, dy, dz);
		
		Circle rear = submarine.rear();
		circleMover.move(rear, dx, dy, dz);
		
		Circle rear1 = submarine.rear1();
		circleMover.move(rear1, dx, dy, dz);
		
		Circle innerFront = submarine.innerFront();
		circleMover.move(innerFront, dx, dy, dz);
		
		Circle innerRear = submarine.innerRear();
		circleMover.move(innerRear, dx, dy, dz);
		
		Circle innerRear1 = submarine.innerRear1();
		circleMover.move(innerRear1, dx, dy, dz);
		
		Rectangle tail = submarine.tail();
		RectangleMover rectangleMover=new RectangleMover();
		rectangleMover.move(tail, dx, dy, dz);
		
		Rectangle base = submarine.base();
		rectangleMover.move(base, dx, dy, dz);
	}
}
