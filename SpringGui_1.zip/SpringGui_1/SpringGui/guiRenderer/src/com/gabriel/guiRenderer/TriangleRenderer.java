package com.gabriel.guiRenderer;

import java.awt.Graphics;

import com.gabriel.guiFx.Renderer;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Triangle;

public class TriangleRenderer implements Renderer{

	@Override
	public void draw(Object object, Shape roof) {
		Graphics g = (Graphics) object; 
		Triangle triangle=(Triangle) roof;
		g.drawPolygon(new int[] {triangle.getLocation().getX(), triangle.getLocation().getY(), triangle.getLocation().getZ()}, new int[] {triangle.getLeg1(), triangle.getLeg2(), triangle.getBase()}, 3);
	}
}
