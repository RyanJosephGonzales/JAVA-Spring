package com.gabriel.guiMover;

import com.gabriel.guiFx.Mover;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Circle;

public class CircleMover implements Mover {

	@Override
	public void move(Shape shape, int dx, int dy, int dz) {
		Circle circle = (Circle) shape;
		circle.getLocation().setX(circle.getLocation().getX()+dx);
		circle.getLocation().setY(circle.getLocation().getY()+dy);
	}
}
