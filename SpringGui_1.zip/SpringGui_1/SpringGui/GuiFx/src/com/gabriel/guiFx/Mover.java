package com.gabriel.guiFx;

public interface Mover {
	void move(Shape shape, int dx, int dy, int dz);
}
