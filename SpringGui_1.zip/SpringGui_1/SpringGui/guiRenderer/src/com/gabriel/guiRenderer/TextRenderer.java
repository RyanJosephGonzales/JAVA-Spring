package com.gabriel.guiRenderer;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import com.gabriel.guiFx.Renderer;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Text;

public class TextRenderer implements Renderer{

    @Override
    public void draw(Object object, Shape shape) {
        Text text = (Text) shape;
         Graphics g = (Graphics) object;
         Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON);
            g.setFont(new Font("Arial", Font.PLAIN, 20)); 
            g2.drawString(text.getText(),text.getLocation().getX(),text.getLocation().getY()); 

    }

}