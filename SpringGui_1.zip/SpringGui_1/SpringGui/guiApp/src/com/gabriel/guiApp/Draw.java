package com.gabriel.guiApp;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import com.gabriel.guiImpl.Submarine;
import com.gabriel.guiMover.SubmarineMover;
import com.gabriel.guiRenderer.SubmarineRenderer;

public class Draw extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Submarine submarine;
	
	
	@Override
	public void paintComponent(Graphics g) {
	     super.paintComponent(g);
	     SubmarineRenderer renderSubmarine=new SubmarineRenderer();
	     renderSubmarine.draw(g, submarine);
	}
	
	public void init() {
		JButton button=new JButton("Move!");
		button.setBounds(200, 380, 30, 20);
		button.setVisible(true);
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				SubmarineMover submarineMover=new SubmarineMover();
				submarineMover.move(submarine, 10, 0, 0);
				repaint();
				
			}
					
			
		});
		add(button);
	}

	public Submarine getSubmarine() {
		return submarine;
	}

	public void setSubmarine(Submarine submarine) {
		this.submarine = submarine;
	}
	
	
	
	
}
