package com.gabriel.guiImpl;

import com.gabriel.guiFx.BaseShape;

public class Circle extends BaseShape {
	private int width;
	private int height;
	public Circle(int width, int height) {
		super();
		this.width = width;
		this.height = height;
	}
	
	public int width() {
		return width;
	}
	
	public int height() {
		return height;
	}


	
/*	
	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	
*/	
}
