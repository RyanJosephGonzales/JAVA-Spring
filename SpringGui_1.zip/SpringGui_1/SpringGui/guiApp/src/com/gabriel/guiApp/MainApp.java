package com.gabriel.guiApp;

import java.awt.Color;

//import javax.annotation.Resource;
import javax.swing.JFrame;

import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*;


import com.gabriel.guiImpl.Submarine;

public class MainApp extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		MainApp mainApp=new MainApp();
		mainApp.setTitle("Under the sea");
		mainApp.setBounds(100,100, 700, 700);
		Draw draw= new Draw();
		draw.setBounds(0,0, 100,100);
		draw.setBackground(Color.blue);
		draw.setForeground(Color.green);		
		draw.init();
		mainApp.add(draw);
		
		ClassPathResource r= new ClassPathResource("ApplicationContext.xml");  
        BeanFactory factory=new XmlBeanFactory((org.springframework.core.io.Resource) r);  
        
        Submarine submarine=(Submarine) factory.getBean("submarine");
		
        draw.setSubmarine(submarine);
		mainApp.setVisible(true);
	
	}
}
