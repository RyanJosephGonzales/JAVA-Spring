package com.gabriel.guiRenderer;


import com.gabriel.guiFx.Renderer;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Circle;
import com.gabriel.guiImpl.Rectangle;
import com.gabriel.guiImpl.Triangle;
import com.gabriel.guiImpl.Text;
import com.gabriel.guiImpl.Submarine;

public class SubmarineRenderer implements Renderer{

	@Override
	public void draw(Object object, Shape shape) {
		
		Submarine submarine=(Submarine) shape;
		
		Circle body = submarine.body();
		Circle rear = submarine.rear();
		Circle rear1 = submarine.rear1();
		Circle front = submarine.front();
		Circle innerRear = submarine.innerRear();
		Circle innerRear1 = submarine.innerRear1();
		Circle innerFront = submarine.innerFront();
		Rectangle tail = submarine.tail();
		Rectangle base = submarine.base();
		Rectangle laser = submarine.laser();
		Rectangle laser1 = submarine.laser1();
		Rectangle laser2 = submarine.laser2();
		Rectangle laser3 = submarine.laser3();
		Rectangle laser4 = submarine.laser4();
		Rectangle laser5 = submarine.laser5();
		Rectangle laser6 = submarine.laser6();
		Rectangle laser7 = submarine.laser7();
		Rectangle laser8 = submarine.laser8();
		Rectangle warningt = submarine.warningt();
		Rectangle warningb = submarine.warningb();
		Triangle warning = submarine.warning();
		Text text = submarine.text();
	
		RectangleRenderer rectangleRenderer=new RectangleRenderer();
		rectangleRenderer.draw(object, tail);
		rectangleRenderer.draw(object, base);
		rectangleRenderer.draw(object, laser);
		rectangleRenderer.draw(object, laser1);
		rectangleRenderer.draw(object, laser2);
		rectangleRenderer.draw(object, laser3);
		rectangleRenderer.draw(object, laser4);
		rectangleRenderer.draw(object, laser5);
		rectangleRenderer.draw(object, laser6);
		rectangleRenderer.draw(object, laser7);
		rectangleRenderer.draw(object, laser8);
		rectangleRenderer.draw(object, warningt);
		rectangleRenderer.draw(object, warningb);
		CircleRenderer circleRenderer=new CircleRenderer();
		circleRenderer.draw(object, front);
		circleRenderer.draw(object, rear);
		circleRenderer.draw(object, rear1);
		circleRenderer.draw(object, body);
		circleRenderer.draw(object, innerRear);
		circleRenderer.draw(object, innerRear1);
		circleRenderer.draw(object, innerFront);
		TriangleRenderer triangleRenderer=new TriangleRenderer();
		triangleRenderer.draw(object, warning);
		TextRenderer textRenderer=new TextRenderer();
		textRenderer.draw(object, text);
	
	}

}
