package com.gabriel.guiFx;

public interface Shape {
	Location getLocation();
	void setLocation(Location location);
}
