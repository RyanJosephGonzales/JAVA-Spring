package com.gabriel.guiImpl;

import com.gabriel.guiFx.BaseShape;

public class Submarine extends BaseShape{
	private Circle front;
	private Circle innerFront;
	private Circle rear;
	private Circle innerRear;
    private Circle body;
    private Circle rear1;
    private Circle innerRear1;
    private Rectangle tail;
    private Rectangle base;
    private Rectangle laser;
    private Rectangle laser1;
    private Rectangle laser2;
    private Rectangle laser3;
    private Rectangle laser4;
    private Rectangle laser5;
    private Rectangle laser6;
    private Rectangle laser7;
    private Rectangle laser8;
    private Rectangle warningt;
    private Rectangle warningb;
    private Triangle warning;
    private Text text;
	public Submarine(Circle front, Circle rear, Circle body, Circle rear1, Rectangle tail, Circle innerRear, Circle innerRear1, Circle innerFront, Rectangle base, Rectangle laser, Rectangle laser1, Rectangle laser2, Rectangle laser3, Rectangle laser4, Rectangle laser5, Rectangle laser6, Rectangle laser7, Rectangle laser8, Rectangle warningt, Rectangle warningb, Triangle warning, Text text) {
		super();
		this.front = front;
		this.innerFront = innerFront;
		this.rear = rear;
		this.innerRear = innerRear;
		this.rear1 = rear1;
		this.innerRear1 = innerRear1;
		this.body = body;
		this.tail = tail;
		this.base = base;
		this.laser = laser;
		this.laser1 = laser1;
		this.laser2 = laser2;
		this.laser3 = laser3;
		this.laser4 = laser4;
		this.laser5 = laser5;
		this.laser6 = laser6;
		this.laser7 = laser7;
		this.laser8 = laser8;
		this.warningt = warningt;
		this.warningb = warningb;
		this.warning = warning;
		this.text = text;
	}
	
	public Text text() {
		return text;
	}
	
	public Circle front() {
		return front;
	}
	
	public Circle innerFront() {
		return innerFront;
	}
	
	public Circle rear() {
		return rear;
	}
	
	public Circle innerRear() {
		return innerRear;
	}
	
	public Circle innerRear1() {
		return innerRear1;
	}
	
	public Circle body() {
		return body;
	}
	
	public Rectangle tail() {
		return tail;
	}
	
	public Circle rear1() {
		return rear1;
	}
	
	public Rectangle base() {
		return base;
	}
	
	public Rectangle laser() {
		return laser;
	}
	public Rectangle laser1() {
		return laser1;
	}
	public Rectangle laser2() {
		return laser2;
	}
	public Rectangle laser3() {
		return laser3;
	}
	public Rectangle laser4() {
		return laser4;
	}
	public Rectangle laser5() {
		return laser5;
	}
	public Rectangle laser6() {
		return laser6;
	}
	public Rectangle laser7() {
		return laser7;
	}
	public Rectangle laser8() {
		return laser8;
	}
	public Triangle warning() {
		return warning;
	}
	public Rectangle warningt() {
		return warningt;
	}
	public Rectangle warningb() {
		return warningb;
	}
	
	
}
