package com.gabriel.guiImpl;

import com.gabriel.guiFx.BaseShape;

public class Triangle extends BaseShape {
	private int leg1;
	private int leg2;
	private int base;
	

	public Triangle(int leg1, int leg2, int base) {
		super();
		this.leg1 = leg1;
		this.leg2 = leg2;
		this.base = base;
	}
	
	public int getLeg1() {
		return leg1;
	}

	public int getLeg2() {
		return leg2;
	}

	public int getBase() {
		return base;
	}
	
}
